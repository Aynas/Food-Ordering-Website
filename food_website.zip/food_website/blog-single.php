﻿<!doctype html>
<html lang="en">

<head>
    <?php include('include/head.php') ?>
</head>

<body>
    
    <div class="page-loading">
        <img src="assets\images\loader.gif" alt="">
    </div><!--page-loading end-->
    
    <div class="wrapper">

        <?php include('include/header.php') ?>
        <!--header end-->


        <section class="pager-section text-center">
            <div class="fixed-bg bg4"></div>
            <div class="container">
                <div class="pager-head">
                    <h2>famous vanilla bean cupcakes</h2>
                    <ul>
                        <li><a href="#" title="">Home</a></li>
                        <li><a href="#" title="">Blog</a></li>
                        <li><span>famous vanilla bean cupcakes</span></li>
                    </ul>
                </div><!--pager-head end-->
            </div>
        </section><!--pager-section end-->

        <section class="sec-block">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="blog-posts">
                            <div class="blog single">
                                <div class="blog-thumbnail">
                                    <img src="assets\images\resources\blog-large1.jpg" alt="" class="w-100">
                                </div>
                                <div class="blog-info">
                                    <ul class="meta">
                                        <li>
                                            <span class="category">recipe</span>
                                        </li>
                                        <li>
                                            <img src="assets\images\resources\meta.jpg" alt="">
                                            <a href="#" title="">Antonio Refflis</a>
                                        </li>
                                        <li>
                                            <a href="#" title="">May 15, 2020</a>
                                        </li>
                                    </ul><!--meta end-->
                                    <div class="d-flex flex-wrap">
                                        <h4>P</h4>
                                        <p>Preheat oven to 350°F and prepare the cupcake pan: Line a 12-cup muffin or cupcake tin with cupcake liners and set aside. 2 Steep vanilla bean pod and seeds in hot milk: While the oven preheats, cut open and scrape out the seeds of a vanilla bean.</p>
                                    </div>
                                    <p>Place the seeds, empty bean, and the milk in a small saucepan. Warm over medium heat for a few minutes until the milk is just starting to steam. Be careful not to boil or scald the milk. Remove from heat and allow the milk to cool with the vanilla beans. After it cools, remove the bean pod. (Wash it and then place it out to dry so it can be used again.). Whisk together dry ingredients In one bowl whisk together the flour, baking powder, and salt.</p>
                                    <blockquote>
                                        <img class="icon-quote" src="assets\images\icons\icon-quote.svg" alt="">
                                        <p>“It raises my hackles when someone calls something “plain vanilla.” Plain? Plain?! Are they insane?! There’s nothing plain about vanilla!”</p>
                                        <h4>Luchano Jemenez</h4>
                                    </blockquote>
                                    <p>Whisk vanilla milk, extract, and sour cream: In another bowl whisk together the vanilla-steeped milk, vanilla extract, and sour cream. Begin making the cupcake batter: Beat the butter in the bowl of a stand mixer fitted with a beater attachment for about 3 minutes on medium speed, then add the sugar and beat until light and fluffy, about 3 minutes.</p>
                                </div>
                                <div class="share-tags d-flex flex-wrap align-items-center">
                                    <div class="share-options">
                                        <h5>Share:</h5>
                                        <ul>
                                            <li><a href="#" title="">Facebook</a></li>
                                            <li><a href="#" title="">Twitter</a></li>
                                            <li><a href="#" title="">Instagram</a></li>
                                        </ul>
                                    </div>
                                    <div class="post-tags">
                                        <ul>
                                            <li><a href="#" title="">Pastry</a></li>
                                            <li><a href="#" title="">Desert</a></li>
                                            <li><a href="#" title="">Recepe</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div><!--blog end-->
                            <div class="blog-author d-flex flex-wrap">
                                <div class="blog-author-thumb">
                                    <img src="assets\images\resources\author-thumb1.jpg" alt="">
                                </div>
                                <div class="blog-author-info">
                                    <h4><a href="#" title="">Skyler olinpton</a></h4>
                                    <p>Web developer since 2008. Create hundreds of websites, HTML and CSS3 expert, who started to learn web design on a world-class level.</p>
                                    <ul class="ul-list">
                                        <li><a href="#" title="">Facebook</a></li>
                                        <li><a href="#" title="">Twitter</a></li>
                                        <li><a href="#" title="">Instagram</a></li>
                                    </ul>
                                </div><!--blog-author-info end-->
                            </div><!--blog-author end-->
                            <div class="post-controler d-flex flex-wrap">
                                <a href="#" title="" class="prev">
                                    <span>
                                        <svg width="16" height="16" viewbox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M15.7071 8.70711C16.0976 8.31658 16.0976 7.68342 15.7071 7.29289L9.34315 0.928932C8.95262 0.538408 8.31946 0.538408 7.92893 0.928932C7.53841 1.31946 7.53841 1.95262 7.92893 2.34315L13.5858 8L7.92893 13.6569C7.53841 14.0474 7.53841 14.6805 7.92893 15.0711C8.31946 15.4616 8.95262 15.4616 9.34315 15.0711L15.7071 8.70711ZM0 9H15V7H0V9Z" fill="white"></path>
                                        </svg>
                                    </span>
                                    Prev Post
                                </a>
                                <a href="#" title="" class="ml-auto next">
                                    Next Post
                                    <span>
                                        <svg width="16" height="16" viewbox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M15.7071 8.70711C16.0976 8.31658 16.0976 7.68342 15.7071 7.29289L9.34315 0.928932C8.95262 0.538408 8.31946 0.538408 7.92893 0.928932C7.53841 1.31946 7.53841 1.95262 7.92893 2.34315L13.5858 8L7.92893 13.6569C7.53841 14.0474 7.53841 14.6805 7.92893 15.0711C8.31946 15.4616 8.95262 15.4616 9.34315 15.0711L15.7071 8.70711ZM0 9H15V7H0V9Z" fill="white"></path>
                                        </svg>
                                    </span>
                                </a>
                            </div><!--post-controler end-->
                        </div><!--blog-posts end-->
                        <div class="blog-posts">
                            <h3>Recent posts</h3>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="blog">
                                        <div class="blog-thumbnail">
                                            <img src="assets\images\resources\post1.jpg" alt="" class="w-100">
                                            <span class="category">recipe</span>
                                        </div>
                                        <div class="blog-info">
                                            <ul class="meta">
                                                <li>
                                                    <img src="assets\images\resources\meta.jpg" alt="">
                                                    <a href="#" title="">Antonio Refflis</a>
                                                </li>
                                                <li>
                                                    <a href="#" title="">May 15, 2020</a>
                                                </li>
                                            </ul>
                                            <h2 class="blog-title"><a href="blog-single.html" title="">The Traditional recipe of apple pie</a></h2>
                                        </div>
                                    </div><!--blog end-->
                                </div>
                                <div class="col-md-6">
                                    <div class="blog">
                                        <div class="blog-thumbnail">
                                            <img src="assets\images\resources\post1.jpg" alt="" class="w-100">
                                            <span class="category">recipe</span>
                                        </div>
                                        <div class="blog-info">
                                            <ul class="meta">
                                                <li>
                                                    <img src="assets\images\resources\meta.jpg" alt="">
                                                    <a href="#" title="">Carlos Bolitti</a>
                                                </li>
                                                <li>
                                                    <a href="#" title="">May 14, 2020</a>
                                                </li>
                                            </ul>
                                            <h2 class="blog-title"><a href="blog-single.html" title="">famous vanilla bean cupcakes</a></h2>
                                        </div>
                                    </div><!--blog end-->
                                </div>
                            </div>
                        </div><!--blog-posts end-->
                        <div class="feedback-section comments">
                            <h2>Comments (3)</h2>
                            <ul class="testimonials-list">
                                <li>
                                   <div class="test-monial">
                                        <div class="testi_head">
                                            <ul>
                                                <li>
                                                    <img src="assets\images\resources\auth1.jpg" alt="">
                                                    <span>Malana Gulsberg</span>        
                                                </li>
                                                <li>
                                                    May 14, 2020 at 6:54pm
                                                </li>
                                            </ul>
                                        </div>
                                        <p>Quis aliqua sunt nisi consectetur anim ullamco ea. Ut deserunt non voluptate nisiuis aliqua sunt nisi consectetur anim ullamco easunt nisi consectetur anim.</p>
                                    </div><!--test-monial end--> 
                                    <ul>
                                        <li>
                                            <div class="test-monial">
                                                <div class="testi_head">
                                                    <ul>
                                                        <li>
                                                            <img src="assets\images\resources\auth1.jpg" alt="">
                                                            <span>Marta Okland</span>        
                                                        </li>
                                                        <li>
                                                            May 14, 2020 at 6:59pm
                                                        </li>
                                                    </ul>
                                                </div>
                                                <p>Quis aliqua sunt nisi consectetur anim ullamco ea. Ut deserunt non voluptate nisiuis aliqua sunt nisi consectetur anim ullamco easunt nisi consectetur anim.</p>
                                            </div><!--test-monial end-->  
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                   <div class="test-monial">
                                        <div class="testi_head">
                                            <ul>
                                                <li>
                                                    <img src="assets\images\resources\auth1.jpg" alt="">
                                                    <span>Rachel Gregorini</span>        
                                                </li>
                                                <li>
                                                    May 16, 2020 at 3:22pm
                                                </li>
                                            </ul>
                                        </div>
                                        <p>Quis aliqua sunt nisi consectetur anim ullamco ea. Ut deserunt non voluptate nisiuis aliqua sunt nisi consectetur anim ullamco easunt nisi consectetur anim.Quis aliqua sunt nisi consectetur anim ullamco ea. Ut deserunt non voluptate nisiuis aliqua sunt nisi consectetur anim ullamco easunt nisi consectetur anim.</p>
                                    </div><!--test-monial end--> 
                                </li>
                            </ul>
                        </div><!--comments end-->
                        <div class="contact-us-section v2">
                            <h2>Leave a Reply</h2>
                            <form id="contact-form" method="post" action="#">
                                <div class="response"></div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <input type="text" name="name" class="form-control name half-radius" placeholder="Name*">
                                        </div><!--form-group end-->
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <input type="email" name="email" class="form-control email half-radius" placeholder="Email*">
                                        </div><!--form-group end-->
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <input type="text" name="website" class="form-control half-radius" placeholder="Website">
                                        </div><!--form-group end-->
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <textarea name="message" placeholder="Message"></textarea>
                                        </div><!--form-group end-->
                                    </div>
                                    <div class="col-md-12">
                                        <button type="button" id="submit" class="btn-default">Post comment <span></span></button>
                                    </div>
                                </div>
                            </form>
                        </div><!--contact-us-section end-->
                    </div>
                    <div class="col-lg-4">
                        <div class="sidebar">
                            <div class="widget widget-search">
                                <form>
                                    <input type="text" name="search" placeholder="Search">
                                    <button type="submit"><img src="assets\images\icons\search.svg" alt=""></button>
                                </form>
                            </div><!--widget-search end-->
                            <div class="widget widget-related-posts">
                                <h3 class="widget-title">Related posts</h3>
                                <div class="widget-posts">
                                    <div class="widget-post">
                                        <img src="assets\images\resources\wid-post1.jpg" alt="" class="w-100">
                                        <h4><a href="#" title="">the most tasty cake we’ve ever made</a></h4>
                                        <span>Jan 17, 2020</span>
                                    </div><!--widget-post end-->
                                    <div class="widget-post">
                                        <img src="assets\images\resources\wid-post1.jpg" alt="" class="w-100">
                                        <h4><a href="#" title="">Everyone's favorite grilled salmon steak</a></h4>
                                        <span>Jan 17, 2020</span>
                                    </div><!--widget-post end-->
                                </div><!--widget-posts end-->
                            </div><!--widget-related-posts end-->
                            <div class="widget widget-categories">
                                <h3 class="widget-title">Categories</h3>
                                <ul>
                                    <li>
                                        <a href="#" title="">Pastry</a>
                                        <span>(15)</span>
                                    </li>
                                    <li>
                                        <a href="#" title="">Hot dishes</a>
                                        <span>(18)</span>
                                    </li>
                                    <li>
                                        <a href="#" title="">Salads</a>
                                        <span>(11)</span>
                                    </li>
                                    <li>
                                        <a href="#" title="">Fastfood</a>
                                        <span>(5)</span>
                                    </li>
                                    <li>
                                        <a href="#" title="">News</a>
                                        <span>(21)</span>
                                    </li>
                                </ul>
                            </div><!--widget-categories end-->
                            <div class="widget widget-newsletter">
                                <h3 class="widget-title">Newsletter</h3>
                                <p>Don’t miss promotions and discounts.</p>
                                <form>
                                    <input type="email" name="email" placeholder="Enter your email" class="half-radius">
                                    <button type="submit" class="btn-default w-100 text-center">Subscribe <span></span></button>
                                </form>
                                <h4>Subscribe</h4>
                            </div><!--widget-newsletter end-->
                            <div class="widget widget-tags">
                                <h3 class="widget-title">Tags</h3>
                                <ul>
                                    <li><a href="#" title="">Fish</a></li>
                                    <li><a href="#" title="">Grill</a></li>
                                    <li><a href="#" title="">Beer</a></li>
                                    <li><a href="#" title="">Chicken</a></li>
                                    <li><a href="#" title="">Beef</a></li>
                                    <li><a href="#" title="">Hot</a></li>
                                    <li><a href="#" title="">Vegetables</a></li>
                                    <li><a href="#" title="">Chilly</a></li>
                                    <li><a href="#" title="">Fruits</a></li>
                                </ul>
                            </div><!--widget-tags end-->
                        </div><!--sidebar end-->
                    </div>
                </div>
            </div>
        </section>

        <?php include('include/footer.php') ?>
        <!--footer end-->
        
    </div><!--wrapper end-->


    <script src="assets\js\jquery.min.js"></script>
    <script src="assets\js\bootstrap.min.js"></script>
    <script src="assets\js\lib\slick\slick.js"></script>
    <script src="assets\js\scripts.js"></script>

</body>
</html>