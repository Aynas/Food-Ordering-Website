<meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <meta name="description" content="Delitaste - Food delivery and Restaurant HTML Template">
    <meta name="author" content="George_Fx">
    <meta name="keywords" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="assets\images\favicon.png">
    <link rel="stylesheet" type="text/css" href="assets\css\all.min.css">
    <link rel="stylesheet" type="text/css" href="assets\css\animate.min.css">
    <link rel="stylesheet" type="text/css" href="assets\js\lib\slick\slick.css">
    <link rel="stylesheet" type="text/css" href="assets\js\lib\slick\slick-theme.css">
    <link rel="stylesheet" type="text/css" href="assets\css\flaticon.css">
    <link rel="stylesheet" type="text/css" href="assets\css\style.css">
    <link rel="stylesheet" type="text/css" href="assets/css/responsive.css">


    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css"><link rel="stylesheet" href="./style.css">