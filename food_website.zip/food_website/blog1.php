﻿<!doctype html>
<html lang="en">

<head>
    <?php include('include/head.php') ?>
</head>

<body>
    
    <div class="page-loading">
        <img src="assets\images\loader.gif" alt="">
    </div><!--page-loading end-->
    
    <div class="wrapper">

        <?php include('include/header.php') ?>
        <!--header end-->

    
        <section class="pager-section text-center">
            <div class="fixed-bg bg4"></div>
            <div class="container">
                <div class="pager-head">
                    <h2>Blog 1</h2>
                    <ul>
                        <li><a href="#" title="">Home</a></li>
                        <li><span>Blog 1</span></li>
                    </ul>
                </div><!--pager-head end-->
            </div>
        </section><!--pager-section end-->

        <section class="sec-block">
            <div class="container">
                <div class="blog-posts blog-page">
                    <div class="row">
                        <div class="col-lg-4 col-md-6">
                            <div class="blog">
                                <div class="blog-thumbnail">
                                    <img src="assets\images\resources\post1.jpg" alt="" class="w-100">
                                    <span class="category">recipe</span>
                                </div>
                                <div class="blog-info">
                                    <ul class="meta">
                                        <li>
                                            <img src="assets\images\resources\meta.jpg" alt="">
                                            <a href="#" title="">Antonio Refflis</a>
                                        </li>
                                        <li>
                                            <a href="#" title="">May 15, 2020</a>
                                        </li>
                                    </ul>
                                    <h2 class="blog-title"><a href="blog-single.html" title="">The Traditional recipe of apple pie</a></h2>
                                </div>
                            </div><!--blog end-->
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="blog">
                                <div class="blog-thumbnail">
                                    <img src="assets\images\resources\post2.jpg" alt="" class="w-100">
                                    <span class="category">recipe</span>
                                </div>
                                <div class="blog-info">
                                    <ul class="meta">
                                        <li>
                                            <img src="assets\images\resources\meta.jpg" alt="">
                                            <a href="#" title="">Carlos Bolitti</a>
                                        </li>
                                        <li>
                                            <a href="#" title="">May 14, 2020</a>
                                        </li>
                                    </ul>
                                    <h2 class="blog-title"><a href="blog-single.html" title="">famous vanilla bean cupcakes</a></h2>
                                </div>
                            </div><!--blog end-->
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="blog">
                                <div class="blog-thumbnail">
                                    <img src="assets\images\resources\post3.jpg" alt="" class="w-100">
                                    <span class="category">recipe</span>
                                </div>
                                <div class="blog-info">
                                    <ul class="meta">
                                        <li>
                                            <img src="assets\images\resources\meta.jpg" alt="">
                                            <a href="#" title="">Nicolas Mano</a>
                                        </li>
                                        <li>
                                            <a href="#" title="">May 12, 2020</a>
                                        </li>
                                    </ul>
                                    <h2 class="blog-title"><a href="blog-single.html" title="">the most tasty cake we’ve ever made</a></h2>
                                </div>
                            </div><!--blog end-->
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="blog">
                                <div class="blog-thumbnail">
                                    <img src="assets\images\resources\post4.jpg" alt="" class="w-100">
                                    <span class="category">recipe</span>
                                </div>
                                <div class="blog-info">
                                    <ul class="meta">
                                        <li>
                                            <img src="assets\images\resources\meta.jpg" alt="">
                                            <a href="#" title="">Antonio Refflis</a>
                                        </li>
                                        <li>
                                            <a href="#" title="">May 11, 2020</a>
                                        </li>
                                    </ul>
                                    <h2 class="blog-title"><a href="blog-single.html" title="">creamy soup with shrimp and garlic</a></h2>
                                </div>
                            </div><!--blog end-->
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="blog">
                                <div class="blog-thumbnail">
                                    <img src="assets\images\resources\post5.jpg" alt="" class="w-100">
                                    <span class="category">recipe</span>
                                </div>
                                <div class="blog-info">
                                    <ul class="meta">
                                        <li>
                                            <img src="assets\images\resources\meta.jpg" alt="">
                                            <a href="#" title="">Carlos Bolitti</a>
                                        </li>
                                        <li>
                                            <a href="#" title="">May 10, 2020</a>
                                        </li>
                                    </ul>
                                    <h2 class="blog-title"><a href="blog-single.html" title="">traditional caesar salad with bacon</a></h2>
                                </div>
                            </div><!--blog end-->
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="blog">
                                <div class="blog-thumbnail">
                                    <img src="assets\images\resources\post6.jpg" alt="" class="w-100">
                                    <span class="category">recipe</span>
                                </div>
                                <div class="blog-info">
                                    <ul class="meta">
                                        <li>
                                            <img src="assets\images\resources\meta.jpg" alt="">
                                            <a href="#" title="">Nicolas Mano</a>
                                        </li>
                                        <li>
                                            <a href="#" title="">May 9, 2020</a>
                                        </li>
                                    </ul>
                                    <h2 class="blog-title"><a href="blog-single.html" title="">everyone's favorite grilled salmon steak</a></h2>
                                </div>
                            </div><!--blog end-->
                        </div>
                    </div>
                    <div class="load-more mt-40 text-center">
                        <a href="#" title="" class="btn-default">Load More <span></span></a>
                    </div>
                </div><!--blog-posts end-->
            </div>
        </section>

        <?php include('include/footer.php') ?><!--footer end-->
        
    </div><!--wrapper end-->


    <script src="assets\js\jquery.min.js"></script>
    <script src="assets\js\bootstrap.min.js"></script>
    <script src="assets\js\lib\slick\slick.js"></script>
    <script src="assets\js\scripts.js"></script>

</body>
</html>