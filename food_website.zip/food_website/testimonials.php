﻿<!doctype html>
<html lang="en">

<head>
    <?php include('include/head.php') ?>
</head>

<body>
    
    <div class="page-loading">
        <img src="assets\images\loader.gif" alt="">
    </div><!--page-loading end-->
    
    <div class="wrapper">

        <?php include('include/header.php') ?><!--header end-->

        

        <section class="pager-section text-center">
            <div class="fixed-bg bg4"></div>
            <div class="container">
                <div class="pager-head">
                    <h2>Testimonials</h2>
                    <ul>
                        <li><a href="#" title="">Home</a></li>
                        <li><a href="#" title="">About us</a></li>
                        <li><span>Testimonials</span></li>
                    </ul>
                </div><!--pager-head end-->
            </div>
        </section><!--pager-section end-->

        <section class="sec-block">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="testimonials-list">
                            <div class="test-monial">
                                <div class="testi_head">
                                    <ul>
                                        <li>
                                            <img src="assets\images\resources\auth1.jpg" alt="">
                                            <span>Carlos Bolitti</span>        
                                        </li>
                                        <li>
                                            May 18, 2020
                                        </li>
                                    </ul>
                                    <span class="quote-icon">
                                        <svg width="70" height="70" viewbox="0 0 70 70" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M69.9842 21.4492C69.9842 21.4416 69.9851 21.434 69.9851 21.4264C69.9851 12.2235 62.5248 4.76318 53.3218 4.76318C44.1189 4.76318 36.6588 12.2233 36.6588 21.4264C36.6588 30.6295 44.1197 38.0897 53.322 38.0897C55.2133 38.0897 57.0238 37.76 58.7179 37.1791C54.9689 58.6857 38.1978 72.5552 53.7444 61.1403C70.9835 48.4824 70.0035 21.9348 69.9842 21.4492Z" fill="#F4F7FD"></path>
                                            <path d="M16.6632 38.0895C18.5546 38.0895 20.3651 37.7598 22.0599 37.1789C18.31 58.6855 1.5389 72.5551 17.0857 61.1401C34.3247 48.4824 33.3449 21.9348 33.3255 21.4492C33.3255 21.4416 33.3263 21.434 33.3263 21.4264C33.3263 12.2235 25.8662 4.76318 16.6632 4.76318C7.46014 4.76318 0 12.2233 0 21.4264C0 30.6295 7.46097 38.0895 16.6632 38.0895Z" fill="#F4F7FD"></path>
                                        </svg>
                                    </span>
                                </div>
                                <p>Very cool team. They work quickly and smoothly. They delivered food on time, the dishes were still hot and the drinks were cold. Good service I will recommend it to everyone.</p>
                            </div><!--test-monial end-->
                            <div class="test-monial">
                                <div class="testi_head">
                                    <ul>
                                        <li>
                                            <img src="assets\images\resources\auth1.jpg" alt="">
                                            <span>Lili Martin</span>        
                                        </li>
                                        <li>
                                            May 14, 2020
                                        </li>
                                    </ul>
                                    <span class="quote-icon">
                                        <svg width="70" height="70" viewbox="0 0 70 70" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M69.9842 21.4492C69.9842 21.4416 69.9851 21.434 69.9851 21.4264C69.9851 12.2235 62.5248 4.76318 53.3218 4.76318C44.1189 4.76318 36.6588 12.2233 36.6588 21.4264C36.6588 30.6295 44.1197 38.0897 53.322 38.0897C55.2133 38.0897 57.0238 37.76 58.7179 37.1791C54.9689 58.6857 38.1978 72.5552 53.7444 61.1403C70.9835 48.4824 70.0035 21.9348 69.9842 21.4492Z" fill="#F4F7FD"></path>
                                            <path d="M16.6632 38.0895C18.5546 38.0895 20.3651 37.7598 22.0599 37.1789C18.31 58.6855 1.5389 72.5551 17.0857 61.1401C34.3247 48.4824 33.3449 21.9348 33.3255 21.4492C33.3255 21.4416 33.3263 21.434 33.3263 21.4264C33.3263 12.2235 25.8662 4.76318 16.6632 4.76318C7.46014 4.76318 0 12.2233 0 21.4264C0 30.6295 7.46097 38.0895 16.6632 38.0895Z" fill="#F4F7FD"></path>
                                        </svg>
                                    </span>
                                </div>
                                <p>I ordered food from two different restaurants at the same time which are far from each other but the guys did very well and delivered the food on time hot and fresh. Everything was as tasty and beautiful as in the restaurant. Food has not lost its beautiful appearance.</p>
                            </div><!--test-monial end-->
                            <div class="test-monial">
                                <div class="testi_head">
                                    <ul>
                                        <li>
                                            <img src="assets\images\resources\auth1.jpg" alt="">
                                            <span>Manuel Bonturini</span>        
                                        </li>
                                        <li>
                                            May 13, 2020
                                        </li>
                                    </ul>
                                    <span class="quote-icon">
                                        <svg width="70" height="70" viewbox="0 0 70 70" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M69.9842 21.4492C69.9842 21.4416 69.9851 21.434 69.9851 21.4264C69.9851 12.2235 62.5248 4.76318 53.3218 4.76318C44.1189 4.76318 36.6588 12.2233 36.6588 21.4264C36.6588 30.6295 44.1197 38.0897 53.322 38.0897C55.2133 38.0897 57.0238 37.76 58.7179 37.1791C54.9689 58.6857 38.1978 72.5552 53.7444 61.1403C70.9835 48.4824 70.0035 21.9348 69.9842 21.4492Z" fill="#F4F7FD"></path>
                                            <path d="M16.6632 38.0895C18.5546 38.0895 20.3651 37.7598 22.0599 37.1789C18.31 58.6855 1.5389 72.5551 17.0857 61.1401C34.3247 48.4824 33.3449 21.9348 33.3255 21.4492C33.3255 21.4416 33.3263 21.434 33.3263 21.4264C33.3263 12.2235 25.8662 4.76318 16.6632 4.76318C7.46014 4.76318 0 12.2233 0 21.4264C0 30.6295 7.46097 38.0895 16.6632 38.0895Z" fill="#F4F7FD"></path>
                                        </svg>
                                    </span>
                                </div>
                                <p>Very cool team. They work quickly and smoothly. They delivered food on time, the dishes were still hot and the drinks were cold. Good service I will recommend it to everyone.</p>
                            </div><!--test-monial end-->
                            <div class="test-monial">
                                <div class="testi_head">
                                    <ul>
                                        <li>
                                            <img src="assets\images\resources\auth1.jpg" alt="">
                                            <span>Alex Dreeman</span>        
                                        </li>
                                        <li>
                                            May 12, 2020
                                        </li>
                                    </ul>
                                    <span class="quote-icon">
                                        <svg width="70" height="70" viewbox="0 0 70 70" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M69.9842 21.4492C69.9842 21.4416 69.9851 21.434 69.9851 21.4264C69.9851 12.2235 62.5248 4.76318 53.3218 4.76318C44.1189 4.76318 36.6588 12.2233 36.6588 21.4264C36.6588 30.6295 44.1197 38.0897 53.322 38.0897C55.2133 38.0897 57.0238 37.76 58.7179 37.1791C54.9689 58.6857 38.1978 72.5552 53.7444 61.1403C70.9835 48.4824 70.0035 21.9348 69.9842 21.4492Z" fill="#F4F7FD"></path>
                                            <path d="M16.6632 38.0895C18.5546 38.0895 20.3651 37.7598 22.0599 37.1789C18.31 58.6855 1.5389 72.5551 17.0857 61.1401C34.3247 48.4824 33.3449 21.9348 33.3255 21.4492C33.3255 21.4416 33.3263 21.434 33.3263 21.4264C33.3263 12.2235 25.8662 4.76318 16.6632 4.76318C7.46014 4.76318 0 12.2233 0 21.4264C0 30.6295 7.46097 38.0895 16.6632 38.0895Z" fill="#F4F7FD"></path>
                                        </svg>
                                    </span>
                                </div>
                                <p>Very fast delivery. I recommend to everyone. The food is very hot and fresh and also as tasty as in a restaurant. The application is very convenient and understandable. Very fast delivery. I recommend to everyone. The food is very hot and fresh and also as tasty as in a restaurant.</p>
                            </div><!--test-monial end-->
                            <div class="test-monial">
                                <div class="testi_head">
                                    <ul>
                                        <li>
                                            <img src="assets\images\resources\auth1.jpg" alt="">
                                            <span>Laura Olister</span>        
                                        </li>
                                        <li>
                                            May 10, 2020
                                        </li>
                                    </ul>
                                    <span class="quote-icon">
                                        <svg width="70" height="70" viewbox="0 0 70 70" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M69.9842 21.4492C69.9842 21.4416 69.9851 21.434 69.9851 21.4264C69.9851 12.2235 62.5248 4.76318 53.3218 4.76318C44.1189 4.76318 36.6588 12.2233 36.6588 21.4264C36.6588 30.6295 44.1197 38.0897 53.322 38.0897C55.2133 38.0897 57.0238 37.76 58.7179 37.1791C54.9689 58.6857 38.1978 72.5552 53.7444 61.1403C70.9835 48.4824 70.0035 21.9348 69.9842 21.4492Z" fill="#F4F7FD"></path>
                                            <path d="M16.6632 38.0895C18.5546 38.0895 20.3651 37.7598 22.0599 37.1789C18.31 58.6855 1.5389 72.5551 17.0857 61.1401C34.3247 48.4824 33.3449 21.9348 33.3255 21.4492C33.3255 21.4416 33.3263 21.434 33.3263 21.4264C33.3263 12.2235 25.8662 4.76318 16.6632 4.76318C7.46014 4.76318 0 12.2233 0 21.4264C0 30.6295 7.46097 38.0895 16.6632 38.0895Z" fill="#F4F7FD"></path>
                                        </svg>
                                    </span>
                                </div>
                                <p>I ordered food from two different restaurants at the same time which are far from each other but the guys did very well and delivered the food on time hot and fresh. Everything was as tasty and beautiful as in the restaurant. Food has not lost its beautiful appearance.</p>
                            </div><!--test-monial end-->
                            <div class="load-more mt-40 text-center">
                                <a href="#" title="" class="btn-default">Load More <span></span></a>
                            </div>
                        </div><!--testimonials-list end-->
                    </div>
                    <div class="col-lg-4">
                        <div class="sidebar">
                            <div class="widget widget-help">
                                <h3 class="widget-title">Need help?</h3>
                                <p>If you have more questions please let us know. We will answer as soon as possible.</p>
                                <a href="#" title="" class="btn-default height-2">Contact us <span></span></a>
                            </div><!--widget-help end-->
                            <div class="widget widget-app">
                                <h3 class="widget-title">Download The App</h3>
                                <ul>
                                    <li><img src="assets\images\btn1.png" alt=""></li>
                                    <li><img src="assets\images\btn2.png" alt=""></li>
                                </ul>
                            </div><!--widget-app end-->
                            <div class="widget widget-newsletter">
                                <h3 class="widget-title">Newsletter</h3>
                                <p>Don’t miss promotions and discounts.</p>
                                <form>
                                    <input type="email" name="email" placeholder="Enter your email" class="half-radius">
                                    <button type="submit" class="btn-default w-100 text-center">Subscribe <span></span></button>
                                </form>
                                <h4>Subscribe</h4>
                            </div><!--widget-newsletter end-->
                            <div class="widget widget-review">
                                <h3 class="widget-title">Leave a review</h3>
                                <form>
                                    <input type="text" name="name" placeholder="Name*" class="half-radius">
                                    <input type="email" name="email" placeholder="Email*" class="half-radius">
                                    <textarea name="review" placeholder="Write a review"></textarea>
                                    <button type="submit" class="btn-default">Submit <span></span></button>
                                </form>
                            </div><!--widget-review end-->
                        </div><!--sidebar end-->
                    </div>
                </div>
            </div>
        </section>

        <?php include('include/footer.php') ?><!--footer end-->
        
    </div><!--wrapper end-->


    <script src="assets\js\jquery.min.js"></script>
    <script src="assets\js\bootstrap.min.js"></script>
    <script src="assets\js\lib\slick\slick.js"></script>
    <script src="assets\js\scripts.js"></script>

</body>
</html>