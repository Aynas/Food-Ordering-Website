﻿<!doctype html>
<html lang="en">

<head>
    <?php include('include/head.php') ?>
</head>

<body>
    
    <div class="page-loading">
        <img src="assets\images\loader.gif" alt="">
    </div><!--page-loading end-->
    
    <div class="wrapper">

        <?php include('include/header.php') ?>
        <!--header end-->

     

        <section class="pager-section text-center">
            <div class="fixed-bg bg4"></div>
            <div class="container">
                <div class="pager-head">
                    <h2>Cart</h2>
                    <ul>
                        <li><a href="#" title="">Home</a></li>
                        <li><span>Cart</span></li>
                    </ul>
                </div><!--pager-head end-->
            </div>
        </section><!--pager-section end-->

        <section class="sec-block">
            <div class="container">
                <div class="cart-page">
                    <table>
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Quantity</th>
                                <th>Price</th>
                                <th>Subtotal</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <div class="cart-prod-info d-flex flex-wrap align-items-center">
                                        <img src="assets\images\resources\cart1.jpg" alt="">
                                        <div class="cart-pro-info">
                                            <h4><a href="#" title="">Shrimp and oyster soup</a></h4>
                                            <span>200 g / 354 kcal</span>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="item-counter">
                                        <div class="quantity">
                                            <button class="plus-btn" type="button" name="button">
                                                <i class="fa fa-plus"></i>
                                            </button>
                                            <input type="text" name="name" value="1">
                                            <button class="minus-btn" type="button" name="button">
                                                <i class="fa fa-minus"></i>
                                            </button>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="price">$65.39</span>
                                </td>
                                <td>
                                    <strong class="sub-total">$130.78</strong>
                                </td>
                                <td>
                                    <a href="#" title=""><img src="assets\images\icons\icon-close.svg" alt=""></a>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="cart-prod-info d-flex flex-wrap align-items-center">
                                        <img src="assets\images\resources\cart2.jpg" alt="">
                                        <div class="cart-pro-info">
                                            <h4><a href="#" title="">Rib-eye steaks</a></h4>
                                            <span>200 g / 354 kcal</span>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="item-counter">
                                        <div class="quantity">
                                            <button class="plus-btn" type="button" name="button">
                                                <i class="fa fa-plus"></i>
                                            </button>
                                            <input type="text" name="name" value="1">
                                            <button class="minus-btn" type="button" name="button">
                                                <i class="fa fa-minus"></i>
                                            </button>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="price">$65.39</span>
                                </td>
                                <td>
                                    <strong class="sub-total">$130.78</strong>
                                </td>
                                <td>
                                    <a href="#" title=""><img src="assets\images\icons\icon-close.svg" alt=""></a>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="cart-prod-info d-flex flex-wrap align-items-center">
                                        <img src="assets\images\resources\cart3.jpg" alt="">
                                        <div class="cart-pro-info">
                                            <h4><a href="#" title="">Greek salad</a></h4>
                                            <span>200 g / 354 kcal</span>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="item-counter">
                                        <div class="quantity">
                                            <button class="plus-btn" type="button" name="button">
                                                <i class="fa fa-plus"></i>
                                            </button>
                                            <input type="text" name="name" value="1">
                                            <button class="minus-btn" type="button" name="button">
                                                <i class="fa fa-minus"></i>
                                            </button>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="price">$65.39</span>
                                </td>
                                <td>
                                    <strong class="sub-total">$130.78</strong>
                                </td>
                                <td>
                                    <a href="#" title=""><img src="assets\images\icons\icon-close.svg" alt=""></a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="row justify-content-end align-items-center">
                        <div class="col-lg-8">
                            <div class="update-cart">
                                <a href="#" title=""><img src="assets\images\icons\refresh-ccw.svg" alt=""> Update cart</a>
                            </div>
                            <div class="coupan-code">
                                <div class="form-group">
                                    <input type="text" name="coupan" placeholder="Coupon number" class="form-control half-radius">
                                    <button type="submit" class="btn-default">Apply <span></span></button>
                                </div>
                            </div><!--coupan-code end-->
                            <div class="clearfix"></div>
                        </div>
                    </div>
                    <div class="row justify-content-end">
                        <div class="col-lg-5">
                            <div class="price-table">
                                <ul>
                                    <li>
                                        <h4>Subtotal</h4>
                                        <span>196.35</span>
                                    </li>
                                    <li>
                                        <h4 class="delivery">Delivery</h4>
                                        <span>$25</span>
                                    </li>
                                    <li>
                                        <h4 class="total-price">Total</h4>
                                        <span class="total-price">$221.35</span>
                                    </li>
                                </ul>
                                <a href="checkout.html" title="" class="btn-default text-center w-100">Checkout <span></span></a>
                            </div><!--price-table end-->
                        </div>
                    </div>
                </div><!--cart-page end-->
            </div>
        </section>

        <?php include('include/footer.php') ?>
        <!--footer end-->
        
    </div><!--wrapper end-->


    <script src="assets\js\jquery.min.js"></script>
    <script src="assets\js\bootstrap.min.js"></script>
    <script src="assets\js\lib\slick\slick.js"></script>
    <script src="assets\js\scripts.js"></script>

</body>
</html>