﻿<!doctype html>
<html lang="en">

<head>
    <?php include('include/head.php') ?>
</head>

<body>
    

    <div class="page-loading">
        <img src="assets\images\loader.gif" alt="">
    </div><!--page-loading end-->

    
    <div class="wrapper">

        <?php include('include/header.php') ?>
        <!--header end-->
        <section class="pager-section text-center">
            <div class="fixed-bg bg4"></div>
            <div class="container">
                <div class="pager-head">
                    <h2>Blog 2</h2>
                    <ul>
                        <li><a href="#" title="">Home</a></li>
                        <li><span>Blog 2</span></li>
                    </ul>
                </div><!--pager-head end-->
            </div>
        </section><!--pager-section end-->

        <section class="sec-block">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="blog-posts blog-page">
                            <div class="blog v2">
                                <div class="blog-thumbnail">
                                    <img src="assets\images\resources\blog-large1.jpg" alt="" class="w-100">
                                    <span class="category">recipe</span>
                                </div>
                                <div class="blog-info">
                                    <h2 class="blog-title"><a href="blog-single.html" title="">The Traditional recipe of apple pie</a></h2>
                                    <p>Preheat oven to 350°F and prepare the cupcake pan: Line a 12-cup muffin or cupcake tin with cupcake liners and set aside. 2 Steep vanilla bean pod and seeds in hot milk.</p>
                                    <div class="bottom-meta">
                                        <ul class="meta">
                                            <li>
                                                <img src="assets\images\resources\meta.jpg" alt="">
                                                <a href="#" title="">Antonio Refflis</a>
                                            </li>
                                            <li>
                                                <a href="#" title="">May 15, 2020</a>
                                            </li>
                                        </ul><!--meta end-->
                                        <a href="blog-single.html" title="" class="read-more">Read More <i class="fa fa-long-arrow-alt-right"></i></a>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                            </div><!--blog end-->
                            <div class="blog v2">
                                <div class="blog-thumbnail">
                                    <img src="assets\images\resources\blog-large2.jpg" alt="" class="w-100">
                                    <span class="category">recipe</span>
                                </div>
                                <div class="blog-info">
                                    <h2 class="blog-title"><a href="blog-single.html" title="">traditional caesar salad with bacon</a></h2>
                                    <p>Preheat oven to 350°F and prepare the cupcake pan: Line a 12-cup muffin or cupcake tin with cupcake liners and set aside. 2 Steep vanilla bean pod and seeds in hot milk.</p>
                                    <div class="bottom-meta">
                                        <ul class="meta">
                                            <li>
                                                <img src="assets\images\resources\meta.jpg" alt="">
                                                <a href="#" title="">Antonio Refflis</a>
                                            </li>
                                            <li>
                                                <a href="#" title="">May 14, 2020</a>
                                            </li>
                                        </ul><!--meta end-->
                                        <a href="blog-single.html" title="" class="read-more">Read More <i class="fa fa-long-arrow-alt-right"></i></a>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                            </div><!--blog end-->
                            <div class="blog v2">
                                <div class="blog-thumbnail">
                                    <img src="assets\images\resources\blog-large3.jpg" alt="" class="w-100">
                                    <span class="category">recipe</span>
                                </div>
                                <div class="blog-info">
                                    <h2 class="blog-title"><a href="blog-single.html" title="">famous vanilla bean cupcakes</a></h2>
                                    <p>Preheat oven to 350°F and prepare the cupcake pan: Line a 12-cup muffin or cupcake tin with cupcake liners and set aside. 2 Steep vanilla bean pod and seeds in hot milk.</p>
                                    <div class="bottom-meta">
                                        <ul class="meta">
                                            <li>
                                                <img src="assets\images\resources\meta.jpg" alt="">
                                                <a href="#" title="">Antonio Refflis</a>
                                            </li>
                                            <li>
                                                <a href="#" title="">May 13, 2020</a>
                                            </li>
                                        </ul><!--meta end-->
                                        <a href="blog-single.html" title="" class="read-more">Read More <i class="fa fa-long-arrow-alt-right"></i></a>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                            </div><!--blog end-->
                        </div><!--blog-posts end-->
                        <div class="deli-pagination text-center">
                            <nav aria-label="Page navigation example">
                                <ul class="pagination">
                                    <li class="page-item"><a class="page-link active" href="#">1</a></li>
                                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                                </ul>
                            </nav>
                        </div><!--deli-pagination end-->
                    </div>
                    <div class="col-lg-4">
                        <div class="sidebar">
                            <div class="widget widget-search">
                                <form>
                                    <input type="text" name="search" placeholder="Search">
                                    <button type="submit"><img src="assets\images\icons\search.svg" alt=""></button>
                                </form>
                            </div><!--widget-search end-->
                            <div class="widget widget-related-posts">
                                <h3 class="widget-title">Related posts</h3>
                                <div class="widget-posts">
                                    <div class="widget-post">
                                        <img src="assets\images\resources\wid-post1.jpg" alt="" class="w-100">
                                        <h4><a href="blog-single.html" title="">the most tasty cake we’ve ever made</a></h4>
                                        <span>Jan 17, 2020</span>
                                    </div><!--widget-post end-->
                                    <div class="widget-post">
                                        <img src="assets\images\resources\wid-post2.jpg" alt="" class="w-100">
                                        <h4><a href="blog-single.html" title="">Everyone's favorite grilled salmon steak</a></h4>
                                        <span>Jan 17, 2020</span>
                                    </div><!--widget-post end-->
                                </div><!--widget-posts end-->
                            </div><!--widget-related-posts end-->
                            <div class="widget widget-categories">
                                <h3 class="widget-title">Categories</h3>
                                <ul>
                                    <li>
                                        <a href="#" title="">Pastry</a>
                                        <span>(15)</span>
                                    </li>
                                    <li>
                                        <a href="#" title="">Hot dishes</a>
                                        <span>(18)</span>
                                    </li>
                                    <li>
                                        <a href="#" title="">Salads</a>
                                        <span>(11)</span>
                                    </li>
                                    <li>
                                        <a href="#" title="">Fastfood</a>
                                        <span>(5)</span>
                                    </li>
                                    <li>
                                        <a href="#" title="">News</a>
                                        <span>(21)</span>
                                    </li>
                                </ul>
                            </div><!--widget-categories end-->
                            <div class="widget widget-newsletter">
                                <h3 class="widget-title">Newsletter</h3>
                                <p>Don’t miss promotions and discounts.</p>
                                <form>
                                    <input type="email" name="email" placeholder="Enter your email" class="half-radius">
                                    <button type="submit" class="btn-default w-100 text-center">Subscribe <span></span></button>
                                </form>
                                <h4>Subscribe</h4>
                            </div><!--widget-newsletter end-->
                            <div class="widget widget-tags">
                                <h3 class="widget-title">Tags</h3>
                                <ul>
                                    <li><a href="#" title="">Fish</a></li>
                                    <li><a href="#" title="">Grill</a></li>
                                    <li><a href="#" title="">Beer</a></li>
                                    <li><a href="#" title="">Chicken</a></li>
                                    <li><a href="#" title="">Beef</a></li>
                                    <li><a href="#" title="">Hot</a></li>
                                    <li><a href="#" title="">Vegetables</a></li>
                                    <li><a href="#" title="">Chilly</a></li>
                                    <li><a href="#" title="">Fruits</a></li>
                                </ul>
                            </div><!--widget-tags end-->
                        </div><!--sidebar end-->
                    </div>
                </div>
            </div>
        </section>

        <?php include('include/footer.php') ?><!--footer end-->
        
    </div><!--wrapper end-->


    <script src="assets\js\jquery.min.js"></script>
    <script src="assets\js\bootstrap.min.js"></script>
    <script src="assets\js\lib\slick\slick.js"></script>
    <script src="assets\js\scripts.js"></script>

</body>
</html>