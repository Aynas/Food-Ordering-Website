﻿<!doctype html>
<html lang="en">

<head>
    <?php include('include/head.php') ?>
</head>

<body>
    
    <div class="page-loading">
        <img src="assets\images\loader.gif" alt="">
    </div><!--page-loading end-->

    
    <div class="wrapper">

        <?php include('include/header.php') ?><!--header end-->

       
        <section class="pager-section text-center">
            <div class="fixed-bg bg4"></div>
            <div class="container">
                <div class="pager-head">
                    <h2>Checkout</h2>
                    <ul>
                        <li><a href="#" title="">Home</a></li>
                        <li><span>Checkout</span></li>
                    </ul>
                </div><!--pager-head end-->
            </div>
        </section><!--pager-section end-->

        <section class="sec-block">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="profile-section">
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="orders-tab" data-toggle="tab" href="#orders" role="tab" aria-controls="orders" aria-selected="true">My orders</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="info-tab" data-toggle="tab" href="#info" role="tab" aria-controls="info" aria-selected="false">My info</a>
                                </li>
                            </ul>
                            <div class="tab-content" id="myTabContent">
                                <div class="tab-pane fade show active" id="orders" role="tabpanel" aria-labelledby="orders-tab">
                                    <div class="order-tables-sec">
                                        <div class="ord-head">
                                            <ul>
                                                <li class="date">Date</li>
                                                <li class="delivery">Delivery address</li>
                                                <li class="amount">Amount</li>
                                                <li>Status</li>
                                            </ul>
                                        </div><!--ord-head end-->
                                        <div class="ord-tablez">
                                            <div class="oc-table active">
                                                <div class="oct-table-head">
                                                    <ul>
                                                        <li class="date">May 22, 20</li>
                                                        <li class="delivery">27 Division St, New York, NY 10002</li>
                                                        <li class="amount">$130.57</li>
                                                        <li class="status active">Preparing</li>
                                                    </ul>
                                                    <a href="#" title="" class="tog-down"><i class="fa fa-angle-down"></i></a>
                                                </div><!--oct-table-head end-->
                                                <div class="oct-table-body">
                                                    <ul>
                                                        <li>
                                                            <h4>Shrimp and oyster soup <span>x2</span></h4>
                                                            <span>$130.79</span>
                                                        </li>
                                                        <li>
                                                            <h4>Rib-eye steaks <span>x2</span></h4>
                                                            <span>$31.38</span>
                                                        </li>
                                                        <li>
                                                            <h4>Greek salad <span>x1</span></h4>
                                                            <span>$34.19</span>
                                                        </li>
                                                        <li>
                                                            <h4><strong>Payment Method</strong></h4>
                                                            <span>Credit Card: <strong>****5478</strong></span>
                                                        </li>
                                                    </ul>
                                                </div><!--oct-table-body end-->
                                            </div><!--oc-table end-->
                                            <div class="oc-table">
                                                <div class="oct-table-head">
                                                    <ul>
                                                        <li class="date">May 22, 20</li>
                                                        <li class="delivery">27 Division St, New York, NY 10002</li>
                                                        <li class="amount">$130.57</li>
                                                        <li class="status">Delivered</li>
                                                    </ul>
                                                    <a href="#" title="" class="tog-down"><i class="fa fa-angle-down"></i></a>
                                                </div><!--oct-table-head end-->
                                                <div class="oct-table-body">
                                                    <ul>
                                                        <li>
                                                            <h4>Shrimp and oyster soup <span>x2</span></h4>
                                                            <span>$130.79</span>
                                                        </li>
                                                        <li>
                                                            <h4>Rib-eye steaks <span>x2</span></h4>
                                                            <span>$31.38</span>
                                                        </li>
                                                        <li>
                                                            <h4>Greek salad <span>x1</span></h4>
                                                            <span>$34.19</span>
                                                        </li>
                                                        <li>
                                                            <h4><strong>Payment Method</strong></h4>
                                                            <span>Credit Card: <strong>****5478</strong></span>
                                                        </li>
                                                    </ul>
                                                </div><!--oct-table-body end-->
                                            </div><!--oc-table end-->
                                            <div class="oc-table">
                                                <div class="oct-table-head">
                                                    <ul>
                                                        <li class="date">May 22, 20</li>
                                                        <li class="delivery">27 Division St, New York, NY 10002</li>
                                                        <li class="amount">$130.57</li>
                                                        <li class="status">Delivered</li>
                                                    </ul>
                                                    <a href="#" title="" class="tog-down"><i class="fa fa-angle-down"></i></a>
                                                </div><!--oct-table-head end-->
                                                <div class="oct-table-body">
                                                    <ul>
                                                        <li>
                                                            <h4>Shrimp and oyster soup <span>x2</span></h4>
                                                            <span>$130.79</span>
                                                        </li>
                                                        <li>
                                                            <h4>Rib-eye steaks <span>x2</span></h4>
                                                            <span>$31.38</span>
                                                        </li>
                                                        <li>
                                                            <h4>Greek salad <span>x1</span></h4>
                                                            <span>$34.19</span>
                                                        </li>
                                                        <li>
                                                            <h4><strong>Payment Method</strong></h4>
                                                            <span>Credit Card: <strong>****5478</strong></span>
                                                        </li>
                                                    </ul>
                                                </div><!--oct-table-body end-->
                                            </div><!--oc-table end-->
                                            <div class="oc-table">
                                                <div class="oct-table-head">
                                                    <ul>
                                                        <li class="date">May 22, 20</li>
                                                        <li class="delivery">27 Division St, New York, NY 10002</li>
                                                        <li class="amount">$130.57</li>
                                                        <li class="status">Delivered</li>
                                                    </ul>
                                                    <a href="#" title="" class="tog-down"><i class="fa fa-angle-down"></i></a>
                                                </div><!--oct-table-head end-->
                                                <div class="oct-table-body">
                                                    <ul>
                                                        <li>
                                                            <h4>Shrimp and oyster soup <span>x2</span></h4>
                                                            <span>$130.79</span>
                                                        </li>
                                                        <li>
                                                            <h4>Rib-eye steaks <span>x2</span></h4>
                                                            <span>$31.38</span>
                                                        </li>
                                                        <li>
                                                            <h4>Greek salad <span>x1</span></h4>
                                                            <span>$34.19</span>
                                                        </li>
                                                        <li>
                                                            <h4><strong>Payment Method</strong></h4>
                                                            <span>Credit Card: <strong>****5478</strong></span>
                                                        </li>
                                                    </ul>
                                                </div><!--oct-table-body end-->
                                            </div><!--oc-table end-->
                                            <div class="oc-table">
                                                <div class="oct-table-head">
                                                    <ul>
                                                        <li class="date">May 22, 20</li>
                                                        <li class="delivery">27 Division St, New York, NY 10002</li>
                                                        <li class="amount">$130.57</li>
                                                        <li class="status">Delivered</li>
                                                    </ul>
                                                    <a href="#" title="" class="tog-down"><i class="fa fa-angle-down"></i></a>
                                                </div><!--oct-table-head end-->
                                                <div class="oct-table-body">
                                                    <ul>
                                                        <li>
                                                            <h4>Shrimp and oyster soup <span>x2</span></h4>
                                                            <span>$130.79</span>
                                                        </li>
                                                        <li>
                                                            <h4>Rib-eye steaks <span>x2</span></h4>
                                                            <span>$31.38</span>
                                                        </li>
                                                        <li>
                                                            <h4>Greek salad <span>x1</span></h4>
                                                            <span>$34.19</span>
                                                        </li>
                                                        <li>
                                                            <h4><strong>Payment Method</strong></h4>
                                                            <span>Credit Card: <strong>****5478</strong></span>
                                                        </li>
                                                    </ul>
                                                </div><!--oct-table-body end-->
                                            </div><!--oc-table end-->
                                        </div><!--ord-tablez end-->
                                    </div><!--order-tables-sec end-->
                                </div>
                                <div class="tab-pane fade" id="info" role="tabpanel" aria-labelledby="info-tab">
                                    <div class="order-tables-sec">
                                        <div class="ord-head">
                                            <ul>
                                                <li class="date">Date</li>
                                                <li class="delivery">Delivery address</li>
                                                <li class="amount">Amount</li>
                                                <li>Status</li>
                                            </ul>
                                        </div><!--ord-head end-->
                                        <div class="ord-tablez">
                                            <div class="oc-table active">
                                                <div class="oct-table-head">
                                                    <ul>
                                                        <li class="date">May 22, 20</li>
                                                        <li class="delivery">27 Division St, New York, NY 10002</li>
                                                        <li class="amount">$130.57</li>
                                                        <li class="status active">Preparing</li>
                                                    </ul>
                                                    <a href="#" title="" class="tog-down"><i class="fa fa-angle-down"></i></a>
                                                </div><!--oct-table-head end-->
                                                <div class="oct-table-body">
                                                    <ul>
                                                        <li>
                                                            <h4>Shrimp and oyster soup <span>x2</span></h4>
                                                            <span>$130.79</span>
                                                        </li>
                                                        <li>
                                                            <h4>Rib-eye steaks <span>x2</span></h4>
                                                            <span>$31.38</span>
                                                        </li>
                                                        <li>
                                                            <h4>Greek salad <span>x1</span></h4>
                                                            <span>$34.19</span>
                                                        </li>
                                                        <li>
                                                            <h4><strong>Payment Method</strong></h4>
                                                            <span>Credit Card: <strong>****5478</strong></span>
                                                        </li>
                                                    </ul>
                                                </div><!--oct-table-body end-->
                                            </div><!--oc-table end-->
                                            <div class="oc-table">
                                                <div class="oct-table-head">
                                                    <ul>
                                                        <li class="date">May 22, 20</li>
                                                        <li class="delivery">27 Division St, New York, NY 10002</li>
                                                        <li class="amount">$130.57</li>
                                                        <li class="status">Delivered</li>
                                                    </ul>
                                                    <a href="#" title="" class="tog-down"><i class="fa fa-angle-down"></i></a>
                                                </div><!--oct-table-head end-->
                                                <div class="oct-table-body">
                                                    <ul>
                                                        <li>
                                                            <h4>Shrimp and oyster soup <span>x2</span></h4>
                                                            <span>$130.79</span>
                                                        </li>
                                                        <li>
                                                            <h4>Rib-eye steaks <span>x2</span></h4>
                                                            <span>$31.38</span>
                                                        </li>
                                                        <li>
                                                            <h4>Greek salad <span>x1</span></h4>
                                                            <span>$34.19</span>
                                                        </li>
                                                        <li>
                                                            <h4><strong>Payment Method</strong></h4>
                                                            <span>Credit Card: <strong>****5478</strong></span>
                                                        </li>
                                                    </ul>
                                                </div><!--oct-table-body end-->
                                            </div><!--oc-table end-->
                                            <div class="oc-table">
                                                <div class="oct-table-head">
                                                    <ul>
                                                        <li class="date">May 22, 20</li>
                                                        <li class="delivery">27 Division St, New York, NY 10002</li>
                                                        <li class="amount">$130.57</li>
                                                        <li class="status">Delivered</li>
                                                    </ul>
                                                    <a href="#" title="" class="tog-down"><i class="fa fa-angle-down"></i></a>
                                                </div><!--oct-table-head end-->
                                                <div class="oct-table-body">
                                                    <ul>
                                                        <li>
                                                            <h4>Shrimp and oyster soup <span>x2</span></h4>
                                                            <span>$130.79</span>
                                                        </li>
                                                        <li>
                                                            <h4>Rib-eye steaks <span>x2</span></h4>
                                                            <span>$31.38</span>
                                                        </li>
                                                        <li>
                                                            <h4>Greek salad <span>x1</span></h4>
                                                            <span>$34.19</span>
                                                        </li>
                                                        <li>
                                                            <h4><strong>Payment Method</strong></h4>
                                                            <span>Credit Card: <strong>****5478</strong></span>
                                                        </li>
                                                    </ul>
                                                </div><!--oct-table-body end-->
                                            </div><!--oc-table end-->
                                            <div class="oc-table">
                                                <div class="oct-table-head">
                                                    <ul>
                                                        <li class="date">May 22, 20</li>
                                                        <li class="delivery">27 Division St, New York, NY 10002</li>
                                                        <li class="amount">$130.57</li>
                                                        <li class="status">Delivered</li>
                                                    </ul>
                                                    <a href="#" title="" class="tog-down"><i class="fa fa-angle-down"></i></a>
                                                </div><!--oct-table-head end-->
                                                <div class="oct-table-body">
                                                    <ul>
                                                        <li>
                                                            <h4>Shrimp and oyster soup <span>x2</span></h4>
                                                            <span>$130.79</span>
                                                        </li>
                                                        <li>
                                                            <h4>Rib-eye steaks <span>x2</span></h4>
                                                            <span>$31.38</span>
                                                        </li>
                                                        <li>
                                                            <h4>Greek salad <span>x1</span></h4>
                                                            <span>$34.19</span>
                                                        </li>
                                                        <li>
                                                            <h4><strong>Payment Method</strong></h4>
                                                            <span>Credit Card: <strong>****5478</strong></span>
                                                        </li>
                                                    </ul>
                                                </div><!--oct-table-body end-->
                                            </div><!--oc-table end-->
                                            <div class="oc-table">
                                                <div class="oct-table-head">
                                                    <ul>
                                                        <li class="date">May 22, 20</li>
                                                        <li class="delivery">27 Division St, New York, NY 10002</li>
                                                        <li class="amount">$130.57</li>
                                                        <li class="status">Delivered</li>
                                                    </ul>
                                                    <a href="#" title="" class="tog-down"><i class="fa fa-angle-down"></i></a>
                                                </div><!--oct-table-head end-->
                                                <div class="oct-table-body">
                                                    <ul>
                                                        <li>
                                                            <h4>Shrimp and oyster soup <span>x2</span></h4>
                                                            <span>$130.79</span>
                                                        </li>
                                                        <li>
                                                            <h4>Rib-eye steaks <span>x2</span></h4>
                                                            <span>$31.38</span>
                                                        </li>
                                                        <li>
                                                            <h4>Greek salad <span>x1</span></h4>
                                                            <span>$34.19</span>
                                                        </li>
                                                        <li>
                                                            <h4><strong>Payment Method</strong></h4>
                                                            <span>Credit Card: <strong>****5478</strong></span>
                                                        </li>
                                                    </ul>
                                                </div><!--oct-table-body end-->
                                            </div><!--oc-table end-->
                                        </div><!--ord-tablez end-->
                                    </div><!--order-tables-sec end-->
                                </div>
                            </div>
                        </div><!--profile-section end-->
                    </div>
                    <div class="col-lg-4">
                        <div class="sidebar">
                            <div class="widget widget-help">
                                <h3 class="widget-title">Need help?</h3>
                                <p>If you have more questions please let us know. We will answer as soon as possible.</p>
                                <a href="#" title="" class="btn-default height-2">Contact us <span></span></a>
                            </div><!--widget-help end-->
                            <div class="widget widget-app">
                                <h3 class="widget-title">Download The App</h3>
                                <ul>
                                    <li><img src="assets\images\btn1.png" alt=""></li>
                                    <li><img src="assets\images\btn2.png" alt=""></li>
                                </ul>
                            </div><!--widget-app end-->
                            <div class="widget widget-newsletter">
                                <h3 class="widget-title">Newsletter</h3>
                                <p>Don’t miss promotions and discounts.</p>
                                <form>
                                    <input type="email" name="email" placeholder="Enter your email" class="half-radius">
                                    <button type="submit" class="btn-default w-100 text-center">Subscribe <span></span></button>
                                </form>
                                <h4>Subscribe</h4>
                            </div><!--widget-newsletter end-->
                        </div><!--sidebar end-->
                    </div>
                </div>
            </div>
        </section>

        <?php include('include/footer.php') ?><!--footer end-->
        
    </div><!--wrapper end-->


    <script src="assets\js\jquery.min.js"></script>
    <script src="assets\js\bootstrap.min.js"></script>
    <script src="assets\js\lib\slick\slick.js"></script>
    <script src="assets\js\scripts.js"></script>

</body>
</html>